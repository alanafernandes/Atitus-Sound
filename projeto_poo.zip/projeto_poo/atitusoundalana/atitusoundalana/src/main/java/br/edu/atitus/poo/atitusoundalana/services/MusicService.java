package br.edu.atitus.poo.atitusoundalana.services;

import br.edu.atitus.poo.atitusoundalana.entities.MusicEntity;

public interface MusicService extends GenericService<MusicEntity>{

}
