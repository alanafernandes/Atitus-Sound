package br.edu.atitus.poo.atitusoundalana.services;

import br.edu.atitus.poo.atitusoundalana.entities.ArtistEntity;

public interface ArtistService extends GenericService<ArtistEntity>{

}
 