package br.edu.atitus.poo.atitusoundalana.dtos;

public class Artistdto {
	
	private String name;
	
	private String image;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	
}
