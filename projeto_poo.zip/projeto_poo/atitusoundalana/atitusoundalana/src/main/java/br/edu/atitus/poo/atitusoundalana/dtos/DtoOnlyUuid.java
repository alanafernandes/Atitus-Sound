package br.edu.atitus.poo.atitusoundalana.dtos;

import java.util.UUID;

public class DtoOnlyUuid {
	
	private UUID uuid;

	public UUID getUuid() {
		return uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}
	

}
