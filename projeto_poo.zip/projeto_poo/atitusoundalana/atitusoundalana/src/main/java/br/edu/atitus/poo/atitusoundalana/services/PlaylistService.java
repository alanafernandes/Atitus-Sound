package br.edu.atitus.poo.atitusoundalana.services;

import br.edu.atitus.poo.atitusoundalana.entities.PlaylistEntity;

public interface PlaylistService extends GenericService<PlaylistEntity>{

}
