package br.edu.atitus.poo.atitusoundalana;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtitusoundalanaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtitusoundalanaApplication.class, args);
	}

}
